export const padreAdapter = {
  name: "Padre Terminal",
};
